__author__ = 'ravi'

name = 'jane'
age = 4
gender = 'female'

print "|{}|{}|{}|".format(name, age, gender)
print "|{:>16}|{:>5}|{:>10}|".format(name, age, gender)
print "|{:<16}|{:<5}|{:<10}|".format(name, age, gender)
print "|{:^16}|{:^5}|{:^10}|".format(name, age, gender)
print "|{:16}|{:5}|{:10}|".format(name, age, gender)
