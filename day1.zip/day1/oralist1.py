__author__ = 'ravi'

l = list()

print l
print type(l)
print len(l)