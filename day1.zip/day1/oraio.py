__author__ = 'ravi'
"""
name = raw_input('Enter the name :')
city = raw_input('Enter the city :')

print 'name :', name
print 'city :', city
"""

zip_code = int(raw_input('Enter the zip code :'))

print zip_code
print type(zip_code)
