__author__ = 'ravi'

s = 'python'\

for item in s:
    if item not in ['a', 'e', 'i', 'o', 'u']:
        print "{} : {}".format(item, ord(item))
