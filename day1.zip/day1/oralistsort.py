__author__ = 'ravi'
import random

nums = range(1, 7)

l = ['pam', 'anderson', 'nelson', 'eva', 'wall-e', 'oliver', ]

l.extend(nums)
#print l

random.shuffle(l)

l.sort(reverse=True)
print l