__author__ = 'ravi'

l = range(15)

d3 = filter(lambda n: n%3 == 0, l)

print d3

l = ['pam', 'anderson', 'nelson', 'eva', 'wall-e', 'oliver', 'nancy']

op = filter(lambda name: name.startswith('n'), l)

print op