__author__ = 'ravi'
import pprint

names = ['pam', 'anderson', 'nelson', 'eva']
gender = ['female', 'male', 'male', 'female']
age = [3, 4, 2, 1]


#print zip(names, gender, age)
#parallem iteration

for n, g, a in zip(names, gender, age):
    print "{:>22} {:>12} {:>5}".format(n, g, a)




