__author__ = 'ravi'


print "pampam"
