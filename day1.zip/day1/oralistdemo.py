__author__ = 'ravi'

l = ['pam', 'anderson', 'nelson', 'eva', 'wall-e', 'oliver', 'nancy']

l.reverse()

print l