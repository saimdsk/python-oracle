__author__ = 'ravi'
import math

radius = float(raw_input('Enter the radius :'))
area = math.pi * (radius ** 2)

result = "Radius : {}\nArea : {:.3f}".format(radius, area)

print result.upper()
