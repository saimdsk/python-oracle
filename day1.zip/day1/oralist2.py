__author__ = 'ravi'

l = ['a', 'i', 12.12, 22 / 7, 100, 'peter pan', 'rosvas']

#l.append('peter pan')
value = l.pop(3)

print value
print l

