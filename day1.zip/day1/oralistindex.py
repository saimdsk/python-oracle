__author__ = 'ravi'

l = ['a', 'i', 12.12, 22 / 7, 100, 'peter pan', 'rosvas']

l[3] = 'pi'
print l
print

print l[-2]
print l[:4]
print l[-4:]
