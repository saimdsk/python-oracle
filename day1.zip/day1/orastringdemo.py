__author__ = 'ravi'

path = 'c:\\temp\nancy\beta\template'
print path

print

path = r'c:\\temp\nancy\beta\template'
print path

