__author__ = 'ravi'
import random
rand_value = random.randint(1, 1000)

chance = 1

while chance <= 10:
    user_value = input('Chance : {}\nEnter the guess: '.format(chance))

    if user_value == rand_value:
        print "you won :) !!!!!!!!!!!"
        break
    elif user_value < rand_value:
        print "{}: is lesser".format(user_value)
    elif user_value > rand_value:
        print "{}: is greater".format(user_value)

    print
    chance += 1
else:
    print "you lost, looser :(........"
    exit(1)

