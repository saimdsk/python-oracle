__author__ = 'ravi'

name = 'oracle'
city = 'hyderabad'

print 'name :', name
print 'city :', city

