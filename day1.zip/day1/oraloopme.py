__author__ = 'ravi'

i = 1

while i <= 7:

    if i == 5:
        break
    elif i == 2:
        i += 1
        continue
    else:
        print i
    i += 1
else:
    print "else block of the while"