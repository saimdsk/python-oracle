__author__ = 'ravi'
import pprint

l = ['pam', 'anderson', 'nelson', 'eva', 'wall-e', 'oliver', 'nancy']
#<name>Pam</name>
tagit = lambda value: "<name>{}</name>".format(value.title())

res = map(tagit, l)
res = map(tagit, l)

pprint.pprint(res)













"""
op = map(str.upper, l)

print op
print l

print map(ord, 'ABCD')
"""