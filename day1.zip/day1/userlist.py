import pprint

user_list = list()

with open('/etc/passwd') as fp:
    for line in fp:
        user_list.append(line.split(':')[0].upper())


with open('userlist.dat', 'w') as fw:
    for i, login in enumerate(sorted(user_list), 1):
        content = "{:>6}  {}".format(i, login)
        print content
        fw.write(content+"\n")
