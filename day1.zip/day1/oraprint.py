__author__ = 'ravi'

print 'kim',
print 'amanda',
print 'peterson',
print 'anderson',
print "jane"

