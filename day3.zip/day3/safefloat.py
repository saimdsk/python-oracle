__author__ = 'ravi'
from sys import argv

def safe_float(value):
    try:
        return float(value[1]) / 0
    except ValueError, e:
        print e
    except (IndexError, KeyError), e:
        print e
    except Exception, e:
        print "internal server error"
    finally:
        print "finally block of exception handling "

print safe_float(argv)
