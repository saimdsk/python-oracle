__author__ = 'ravi'

l = [3, 4, 2, 5, 1]


temp = []
for i in l:
    temp.append(i ** i)

print temp

temp2 = [i**i for i in l]  #list comp.
print temp2

binary =  [bin(i) for i in l]
print binary