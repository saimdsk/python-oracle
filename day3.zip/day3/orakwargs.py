__author__ = 'ravi'


def demo(**args):
    print args

d = {'lang': 'perl', 'version': 2.7, 'name': 'larry'}

demo(**d)
#demo(name='larry', lang='perl', version=2.7)