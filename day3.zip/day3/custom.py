__author__ = 'ravi'

class RangeError(Exception):
    def __str__(self):
        return "{}: {}".format(self.__class__.__name__, self.message)

def demo(level):
    try:
        radiation = level

        if radiation >= 0.6:
            raise RangeError('radiation is too high: {}'.format(radiation))

    except RangeError, e:
        print e

demo(0.9)

# ravi.goglobium@gmail.com
# 97909 16181