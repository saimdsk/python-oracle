__author__ = 'ravi'

from orautils import pid, name, ls

print name
pid()
ls('/tmp')
