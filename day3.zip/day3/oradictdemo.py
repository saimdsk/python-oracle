__author__ = 'ravi'

info = {'name': 'perl', 'lang':
        'larry', 'release': 'parrot', 'version': 'beta'}

#for key in sorted(info):
#    print "{} : {}".format(key, info[key])

print

for key in sorted(info, key=lambda k: info[k], reverse=True):
    print "{} : {}".format(key, info[key])

def sortit(key):
    print key
    return info[key]