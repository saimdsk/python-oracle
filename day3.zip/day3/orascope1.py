__author__ = 'ravi'

n = 100  #lives in the global scope


def demo():
    global n  #to refer the global versoin of n
    n = 'pypi'  #defining a local variable
    print n



demo()
print n
