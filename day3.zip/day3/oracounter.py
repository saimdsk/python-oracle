__author__ = 'ravi'

counter = 0

def alarm():
    global counter
    counter += 1

alarm()
alarm()
alarm()

print counter
