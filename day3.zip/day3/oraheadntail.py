__author__ = 'ravi'
import getopt
from sys import argv

def headntail(filename, **param):
    count = param.get('count', 10)
    order = param.get('order', 'head')

    with open(filename) as fw:
        if order == 'head':
            content = fw.readlines()[:count]
        elif order == 'tail':
            content = fw.readlines()[-count:]
        else:
            return None
    return ''.join(content).rstrip()


try:
    opts, args = getopt.gnu_getopt(argv[1:], 'c:o:')
    print opts, args ; exit(1)
    info = {}

    for option, value in opts:
        if option == '-c':
            info['count'] = int(value)
        elif option == '-o':
            info['order'] = value

    print headntail(args[0], **info)
except Exception, e:
    print e