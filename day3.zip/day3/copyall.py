__author__ = 'ravi'
from sys import argv


def copy_all(*file_names):
    with open(file_names[-1], 'w') as fw:
        for filename in file_names[:-1]:
            fw.write(filename.center(60, '-') + '\n')
            fw.write(open(filename).read())
            fw.write('-'.center(60, '-') + '\n')



copy_all(*argv[1:])
print "I add a statement here"