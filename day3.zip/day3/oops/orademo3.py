__author__ = 'ravi'


class Demo(object):
    def __init__(self, data):
        self.data = data
        print "constructor : {}".format(self)

    def get_data(self):
        return self.data

    def __del__(self):
        print "destructor : {}".format(self)


def main():
    d = Demo('pypi')
    print d.get_data()

if __name__ == '__main__':
    main()


