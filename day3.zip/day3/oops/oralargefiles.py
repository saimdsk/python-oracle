__author__ = 'ravi'
from os import listdir, stat
from os.path import isfile, join
from pprint import pprint

class LargeFiles(object):

    def __init__(self, dir_name):
        self.dir_name = dir_name
        self.content = {}
        self.get_files()


    def get_files(self):

        for file_name in filter(lambda fname:
                isfile(join(self.dir_name, fname)), listdir(self.dir_name)):

            abs_path = join(self.dir_name, file_name)

            self.content[file_name] = stat(abs_path).st_size

    def top3files(self, count):
        sort_it = lambda file_name: self.content[file_name]

        for name in sorted(self.content, key=sort_it, reverse=True)[:count]:
            print "{:>24} : {}".format(name, self.content[name])


def main():
    l = LargeFiles('/home/ravi/Training/Python-Oracle/mar30')
    l.top3files(1)

if __name__ == '__main__':
    main()
