__author__ = 'ravi'


class Demo(object):
    pass


def main():
    d = Demo()
    print d
    print Demo
    print type(Demo)
    print type(object)
    print type(d)
    print isinstance(d, Demo)

if __name__ == '__main__':
    main()


