__author__ = 'ravi'


class Demo(object):
    def __init__(self):
        print "constructor : {}".format(self)

    def __del__(self):
        print "destructor : {}".format(self)


def main():
    d = Demo()
    print d

if __name__ == '__main__':
    main()


