__author__ = 'ravi'

class Property(object):
    def __init__(self):
        self.container = {}

    def __setitem__(self, key, value):
        self.container[key] = value

    def __getitem__(self, item):
        return self.container[item]

    def __delitem__(self, key):
        del self.container[key]

def main():
    p = Property()
    p['name'] = 'oralce'
    p['city'] = 'hyderabad'
    p['state'] = 'ts'

    del p['city']

    for item in p.container:
        print "{} : {}".format(item, p[item])

if __name__ == '__main__':
    main()
