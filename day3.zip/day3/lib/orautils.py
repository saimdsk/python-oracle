"""
orautils, a sample python module
"""
from os import listdir, getpid

name = 'oracle'
city = 'hyderabad'
version = '0.0.1'


def ls(path='.'):
    """
    ls(), list the content of the given directory
    :param path: standard path of the filesystem
    :return: None
    """
    for item in listdir(path):
        print item


def pid():
    """
    pid(), gets the current process id
    :return: None
    """
    print "current process id : {}".format(getpid())


def power(x, n=0):
    """
    power() raises x to the power of n
    :param x: integer
    :param n: integer
    :return: integer
    """
    return x ** n

def main():
    print __name__
    print name
    print city
    print power(3, 2)
    pid()

if __name__ == '__main__':
    main()

