__author__ = 'ravi'

def demo(*param):
    print param

l = [1,2,3,4,5,6]

demo(l)
demo(*l)

"""
demo(100)
demo('peter pan')
demo(1,2,3,4, 'v')
"""

