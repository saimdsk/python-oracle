__author__ = 'ravi'

info = {}
print info
print type(info)
print len(info)

