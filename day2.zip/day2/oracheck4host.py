__author__ = 'ravi'
from sys import stderr
from fileinput import input
import subprocess


for host in input():
    host = host.rstrip()
    try:
        cmd = "ping -c 2 {}".format(host)
        subprocess.check_call(cmd, shell=True, stdout=subprocess.PIPE)
        print "{} : up".format(host)
    except:
        print >>stderr, "{} : down".format(host)