__author__ = 'ravi'

names = ['perl', 'pypi', 'ruby']
author = ['larry', 'guido', 'matz']

info = dict(zip(names, author))
print info

for nam, auth in zip(names, author):
    print nam, auth