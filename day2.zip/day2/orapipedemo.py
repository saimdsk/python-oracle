__author__ = 'ravi'
import subprocess

cat = subprocess.Popen('cat /etc/passwd', shell=True, stdout=subprocess.PIPE)

cut = subprocess.Popen('cut -f 1 -d ":"', shell=True,
                       stdin=cat.stdout, stdout=subprocess.PIPE)

sort = subprocess.Popen('sort', shell=True, stdin=cut.stdout,
                        stdout=subprocess.PIPE)

for item in sort.communicate():
    if item:
        print item.rstrip()