__author__ = 'ravi'

from sys import argv, version

print argv
#print version