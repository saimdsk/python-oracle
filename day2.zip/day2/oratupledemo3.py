__author__ = 'ravi'

t = (1,2,3, 'four', 5)

l = list(t)

l[-2] = 4

print tuple(l)