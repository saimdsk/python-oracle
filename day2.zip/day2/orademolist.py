__author__ = 'ravi'

l = ['pypi', 2.7, 'green parror']
uniq_of_l3 = []

l3 = l + l

for item in l3:
    if item not in uniq_of_l3:
        uniq_of_l3.append(item)

print uniq_of_l3


print list(set(l3))
