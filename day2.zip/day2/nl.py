__author__ = 'ravi'

from fileinput import input, lineno

for line in input():
    print "{:>6}  {}".format(lineno(), line.rstrip())
