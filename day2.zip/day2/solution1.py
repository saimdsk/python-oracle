from decimal import Decimal as D

a = 0.1
b = 0.3


res = D(str(a)) + D(str(a)) + D(str(a)) - D(str(b))

print res 
print D(str(a))
print D(a)

