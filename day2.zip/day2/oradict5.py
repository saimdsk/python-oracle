__author__ = 'ravi'
from pprint import pprint

info = {'hostname': 'ws1', 'domain': 'rootcap.in', 'platform': 'linux2'}

info['desc'] = 'web server'

print info['hostname']
print info['domain']
print info['platform']
print info.get('desc')
print info.get('descc')
print info.get('descc', 'unknown key')

