__author__ = 'ravi'
from fileinput import input
import re

regex = r'(\d{2})-(\d{2})-(\d{4}) (\d\d:\d\d:\d\d)'
replace = r'[\4] \3-\1-\2'

for l in input(inplace=True, backup='.bak'):
    print re.sub(regex, replace, l, flags=re.I).rstrip()
