__author__ = 'ravi'
from pprint import pprint

info = {'hostname': 'ws1', 'domain': 'rootcap.in', 'platform': 'linux2'}

if 'platform' in info:
    info['platform'] = 'linux3'

info['desc'] = 'web server'

value = info.pop('domain')
print value
print

pprint(info)

