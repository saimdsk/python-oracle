__author__ = 'ravi'

t = (1,2,3, 'four', 5)

t[-2] = 4

print t
print type(t)
print len(t)
