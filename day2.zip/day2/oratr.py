__author__ = 'ravi'
from string import maketrans
from fileinput import input
from sys import argv


table = maketrans(argv.pop(1), argv.pop(1))

for l in input():
    print l.translate(table).rstrip()
