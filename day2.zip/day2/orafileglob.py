__author__ = 'ravi'
from glob import glob
from os import stat
from os.path import basename

def list_content(path):
    for item in glob(path):
        size = stat(item).st_size
        name = basename(item)
        print "{:>26}  {}".format(name, size)


list_content('./*.py')
