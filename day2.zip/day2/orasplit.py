__author__ = 'ravi'
import re

s = 'root,x:0;0-0.root,xx/root:/bin/bash'

l = re.split(r'[,:;\-./]', s)

print l