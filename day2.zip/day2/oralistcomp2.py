__author__ = 'ravi'

mat = [[1, 2, 3],
       [4, 5, 6, 19],
       [7, 8, 9]]


#print [row[1] for row in mat]

print [col for row in mat if len(row) == 3 for col in row if col % 2]













for row in mat:
    for col in row:
        print "{}\t".format(col),

    print

"""
print mat[1][1]
print mat[-1]
"""





