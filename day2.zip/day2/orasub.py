__author__ = 'ravi'
import re

s = 'this is a sample string in python'

op = re.sub(r'([AEIOU])', r'[\1]', s, flags=re.I)

print op
