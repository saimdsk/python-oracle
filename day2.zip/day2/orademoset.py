__author__ = 'ravi'
u = set(range(1, 11))

a = set([1,3,5,7,9,2,4,8])

b = set([2,4,6,8, 10])

for item in u:
    print item
print u.issuperset(a)

"""
print a.intersection(b)

print a.union(b)

print a.difference(b)
print b - a
"""

