__author__ = 'ravi'
from pprint import pprint

wc = {}

for line in open('message'):
    for word in line.rstrip().split():
        if word in wc:
            wc[word] += 1
        else:
            wc[word] = 1

for word in sorted(wc):
    print "{:>25} : {}".format(word, wc[word])
