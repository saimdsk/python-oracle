__author__ = 'ravi'
import re
from fileinput import input
from sys import argv

regex = argv.pop(1)

for line in input():
    if re.search(regex, line, re.I):
        print line.rstrip()

