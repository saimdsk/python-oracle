__author__ = 'ravi'

info = {'hostname': 'ws1', 'domain': 'rootcap.in', 'platform': 'linux2'}
print type(info)
print len(info)
print info

