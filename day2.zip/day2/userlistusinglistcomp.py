__author__ = 'ravi'
from pprint import pprint



t = [l.split(':')[0].title() for l in open('/etc/passwd')
                if l.startswith('a')]

for i, name in enumerate(sorted(t), 1):
    print "{:>6}  {}".format(i, name)





