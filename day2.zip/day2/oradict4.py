__author__ = 'ravi'
from pprint import pprint

info = {'hostname': 'ws1', 'domain': 'rootcap.in', 'platform': 'linux2'}

info['desc'] = 'web server'

for k in sorted(info):
    print "{} -> {}".format(k, info[k])
