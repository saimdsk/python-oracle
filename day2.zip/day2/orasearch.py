__author__ = 'ravi'
import re

s = 'the python scripting'
m = re.search('P.+?N', s, re.I)
print m

if m:
    print "matched : {}".format(m.group())
    print "start index : {}".format(m.start())
    print m.end()
    print m.span()

else:
    print "failed to match"
