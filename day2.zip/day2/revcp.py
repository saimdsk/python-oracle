__author__ = 'ravi'
from sys import argv


def usage():
    print "Usage :"
    print "{} source-file dest-file".format(argv[0])
    exit(1)

if len(argv) != 3:
    usage()

with open(argv[2], 'w') as fw:
    fw.writelines(open(argv[1]).readlines()[::-1])


