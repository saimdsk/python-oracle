__author__ = 'ravi'

t = ()

print t
print type(t)
print len(t)
