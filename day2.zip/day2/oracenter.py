__author__ = 'ravi'


def center(string, width, fill=' '):
    n = (width - len(string)) / 2

    return "{}{}{}".format(fill * n, string, fill * n)

print center('perl', 10)
print center('perl', 10, '-')